import Link from 'next/link'
import { doctors } from '../../data/doctors'

export const metadata = {
  title: 'Our Doctors | Hope Hospital Varanasi | BHU Affiliated',
  description: 'Meet our expert doctors at Hope Hospital Varanasi — all affiliated with IMS, Banaras Hindu University. Book appointment with Dr. Anil Kumar Tripathi (General & Laparoscopy Surgeon, Ano Rectal Specialist) and Dr. Anjita Kurei (Gynecology).',
}

export default function DoctorsPage() {
  return (
    <div>
      {/* Header */}
      <section className="bg-gradient-to-r from-navy to-blue-800 text-white py-16 px-4 text-center">
        <p className="font-hindi text-blue-200 text-xl mb-2">हमारे डॉक्टर</p>
        <h1 className="font-display font-extrabold text-4xl md:text-5xl mb-4">Meet Our Expert Doctors</h1>
        <p className="text-blue-100 max-w-2xl mx-auto text-lg">
          All our doctors are trained at IMS, Banaras Hindu University — one of India's most prestigious medical institutions.
        </p>
        <div className="mt-6 inline-flex items-center gap-2 bg-white/20 backdrop-blur px-5 py-2 rounded-full text-sm font-semibold">
          🎓 All doctors affiliated with IMS, BHU, Varanasi
        </div>
      </section>

      {/* Doctors */}
      <section className="py-20 px-4 bg-slate-50">
        <div className="max-w-4xl mx-auto space-y-10">
          {doctors.map((doc, i) => (
            <div key={doc.id} className="card overflow-hidden">
              <div className="h-2" style={{ backgroundColor: doc.color }}></div>
              <div className="p-8 flex flex-col md:flex-row gap-8 items-start">
                {/* Avatar */}
                <div className="flex-shrink-0 text-center">
                  <div className="w-32 h-32 rounded-2xl flex items-center justify-center text-white text-4xl font-display font-bold shadow-lg mx-auto"
                    style={{ backgroundColor: doc.color }}>
                    {doc.initials}
                  </div>
                  <div className="mt-3 text-xs text-slate-500">Photo coming soon</div>
                </div>

                {/* Info */}
                <div className="flex-1">
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div>
                      <h2 className="font-display font-extrabold text-slate-900 text-2xl">{doc.name}</h2>
                      <p className="font-hindi text-slate-500 text-lg">{doc.nameHindi}</p>
                    </div>
                    <span className="badge-bhu text-sm px-4 py-2">🎓 {doc.qualification}</span>
                  </div>

                  <p className="font-display font-bold mt-4 text-lg" style={{ color: doc.color }}>
                    {doc.specialization}
                  </p>
                  <p className="font-hindi text-slate-500 text-sm">{doc.specializationHindi}</p>

                  <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="bg-light rounded-xl p-4 text-center">
                      <div className="font-display font-bold text-navy text-lg">{doc.experience}</div>
                      <div className="text-slate-500 text-xs mt-1">Experience</div>
                    </div>
                    <div className="bg-light rounded-xl p-4 text-center">
                      <div className="font-display font-bold text-navy text-sm">{doc.available}</div>
                      <div className="text-slate-500 text-xs mt-1">Available Days</div>
                    </div>
                    <div className="bg-light rounded-xl p-4 text-center">
                      <div className="font-display font-bold text-navy text-sm">{doc.timing}</div>
                      <div className="text-slate-500 text-xs mt-1">OPD Timings</div>
                    </div>
                  </div>

                  <div className="mt-6 flex flex-wrap gap-3">
                    <Link href="/appointment" className="btn-primary">
                      📅 Book Appointment
                    </Link>
                    <a href="tel:+917905711195" className="btn-outline">
                      📞 Call Hospital
                    </a>
                    <a href={`https://wa.me/917905711195?text=Hello%2C%20I%20would%20like%20to%20book%20an%20appointment%20with%20${encodeURIComponent(doc.name)}`}
                      target="_blank" rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 bg-green-600 text-white font-display font-semibold px-5 py-3 rounded-lg hover:bg-green-700 transition-colors">
                      💬 WhatsApp
                    </a>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
