import Link from 'next/link'
import { doctors } from '../data/doctors'
import ServicesSlider from '../components/home/ServicesSlider'

const reviews = [
  { name: 'Ramesh Kumar', text: 'Bahut accha hospital hai. Doctors bahut experienced hain aur staff bhi helpful hai. BHU se affiliated hone ki wajah se poora trust hai.', stars: 5 },
  { name: 'Sunita Devi', text: 'Dr. Anjita ne meri delivery ke time bahut acchi care ki. NICU facility bhi bahut achi hai. Highly recommended.', stars: 5 },
  { name: 'Mohd. Riyaz', text: 'Emergency mein raat ko admit hua tha. Ambulance jaldi aayi aur ICU mein best treatment mila. Doctors ne bahut support kiya.', stars: 5 },
  { name: 'Priya Mishra', text: 'Laparoscopic surgery bahut successful rahi. Dr. Tripathi ka experience clearly dikhta hai. Fast recovery hua.', stars: 5 },
  { name: 'Vinod Yadav', text: 'Varanasi mein itna trusted hospital milna mushkil hai. Sab facilities ek jagah milti hain. 24x7 service bahut zaroori thi hamare liye.', stars: 5 },
]

export default function HomePage() {
  return (
    <div>
      {/* ── HERO ── */}
      <section className="bg-gradient-to-br from-navy via-blue-800 to-blue-900 text-white pt-20 pb-24 px-4 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 right-10 w-72 h-72 rounded-full bg-white"></div>
          <div className="absolute bottom-0 left-0 w-48 h-48 rounded-full bg-white"></div>
        </div>
        <div className="max-w-6xl mx-auto relative z-10 flex flex-col md:flex-row items-center gap-10">
          <div className="flex-1 text-center md:text-left">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur px-4 py-2 rounded-full text-sm font-semibold mb-6">
              <span className="text-yellow-300">⭐</span> 4.9/5 Rating • 193+ Google Reviews • IMS, BHU Affiliated
            </div>
            <h1 className="font-display font-extrabold text-4xl md:text-5xl lg:text-6xl leading-tight mb-2">
              Hope Hospital
            </h1>
            <p className="font-hindi text-2xl md:text-3xl text-blue-200 mb-2">होप हॉस्पिटल</p>
            <p className="font-display text-lg text-green-300 font-semibold mb-1 italic">Caring for Life</p>
            <p className="text-blue-200 text-sm mb-4">Super Speciality Center for Ano Rectal Disease</p>
            <p className="text-blue-100 text-lg md:text-xl max-w-xl mb-8 leading-relaxed">
              10+ Specialties • BHU-Trained Doctors • Advanced ICU & NICU • 24x7 Emergency Ambulance
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <Link href="/appointment" className="bg-white text-navy font-display font-bold px-8 py-4 rounded-xl hover:bg-blue-50 transition-colors text-lg shadow-lg">
                📅 Book Appointment
              </Link>
              <a href="tel:+917905711195" className="bg-red-700 font-display font-bold px-8 py-4 rounded-xl hover:bg-red-800 transition-colors text-lg flex items-center justify-center gap-2">
                🚨 Call Emergency
              </a>
            </div>
          </div>
          <div className="flex-shrink-0 grid grid-cols-2 gap-3 text-center">
            {[
              { n: '10+', l: 'Specialties' },
              { n: '24x7', l: 'Emergency' },
              { n: '4.9★', l: 'Google Rating' },
              { n: 'BHU', l: 'Affiliated' },
            ].map(item => (
              <div key={item.n} className="bg-white/15 backdrop-blur rounded-2xl p-5 w-32">
                <div className="font-display font-extrabold text-2xl text-white">{item.n}</div>
                <div className="text-blue-200 text-sm mt-1">{item.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── ADDRESS BAR ── */}
      <section className="bg-navy/95 text-white py-3 px-4">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-sm">
          <div className="flex items-center gap-2">
            <span>📍</span>
            <span>Chunar Rd, near Hemen Jewellers, Awaleshpur, Varanasi, UP 221106</span>
          </div>
          <div className="flex items-center gap-4">
            <a href="tel:+917905711195" className="flex items-center gap-1 text-yellow-300 font-semibold hover:text-yellow-100">
              📞 +91 79057 11195
            </a>
            <span className="text-green-400 font-semibold">🟢 Open 24x7</span>
          </div>
        </div>
      </section>

      {/* ── SERVICES SLIDER ── */}
      <ServicesSlider />

      {/* ── DOCTORS ── */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <p className="font-display font-semibold text-sm uppercase tracking-widest mb-2" style={{color:'#C0392B'}}>Meet The Team</p>
            <h2 className="section-title">Our Expert Doctors</h2>
            <p className="section-sub">BHU-trained specialists with years of clinical excellence</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 justify-items-center">
            {doctors.map(doc => (
              <div key={doc.id} className="card text-center overflow-hidden w-full max-w-sm">
                <div className="h-2" style={{ backgroundColor: doc.color }}></div>
                <div className="p-6">
                  <div className="w-24 h-24 rounded-full mx-auto mb-4 flex items-center justify-center text-white text-3xl font-display font-bold shadow-lg"
                    style={{ backgroundColor: doc.color }}>
                    {doc.initials}
                  </div>
                  <h3 className="font-display font-bold text-slate-900 text-xl">{doc.name}</h3>
                  <p className="font-hindi text-slate-500 text-sm mt-1">{doc.nameHindi}</p>
                  <span className="badge-bhu mt-3">🎓 {doc.qualification}</span>
                  <p className="text-navy font-semibold mt-3 text-sm leading-snug">{doc.specialization}</p>
                  <div className="mt-4 text-xs text-slate-500 space-y-1 border-t pt-4">
                    <div>⏰ {doc.timing}</div>
                    <div>📅 {doc.available}</div>
                    <div className="text-emerald-700 font-semibold">✅ {doc.experience} Experience</div>
                  </div>
                  <Link href="/appointment" className="mt-5 block btn-primary text-sm py-2">
                    Book Appointment
                  </Link>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-10">
            <Link href="/doctors" className="btn-outline">View All Doctors →</Link>
          </div>
        </div>
      </section>

      {/* ── WHY CHOOSE US ── */}
      <section className="py-20 px-4 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <p className="font-display font-semibold text-sm uppercase tracking-widest mb-2" style={{color:'#C0392B'}}>Why Us</p>
            <h2 className="section-title">Why Patients Trust Hope Hospital</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: '🎓', title: 'BHU Affiliated Doctors', desc: 'All our doctors are trained at IMS, Banaras Hindu University — one of India\'s top medical institutions.' },
              { icon: '🚨', title: '24x7 Emergency Care', desc: 'Round-the-clock emergency services with ambulance, ICU & NICU always ready for critical patients.' },
              { icon: '⭐', title: '4.9/5 Patient Rating', desc: '193+ genuine Google reviews from satisfied patients reflecting our commitment to quality care.' },
              { icon: '🔬', title: '10+ Specialties', desc: 'From general surgery to laparoscopic, cancer surgery to neurology — comprehensive care under one roof.' },
              { icon: '🩺', title: 'Ano Rectal Specialist', desc: 'Super Speciality Center for Ano Rectal Disease — Kshar Sutra treatment by expert BHU-trained surgeon.' },
              { icon: '💊', title: 'Modern Equipment', desc: 'Advanced surgical and diagnostic equipment for precise treatment and faster patient recovery.' },
            ].map(item => (
              <div key={item.title} className="card p-6 flex gap-4">
                <div className="text-4xl flex-shrink-0">{item.icon}</div>
                <div>
                  <h3 className="font-display font-bold text-slate-900 text-base mb-1">{item.title}</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── REVIEWS ── */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <p className="font-display font-semibold text-sm uppercase tracking-widest mb-2" style={{color:'#C0392B'}}>Patient Stories</p>
            <h2 className="section-title">What Patients Say</h2>
            <p className="section-sub">Real experiences from our patients</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reviews.map((r, i) => (
              <div key={i} className="card p-6 border border-slate-100">
                <div className="flex gap-1 mb-3">
                  {Array(r.stars).fill(0).map((_, j) => (
                    <span key={j} className="text-yellow-400">★</span>
                  ))}
                </div>
                <p className="font-hindi text-slate-900 text-sm leading-relaxed mb-4">"{r.text}"</p>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-navy text-white flex items-center justify-center text-xs font-bold">
                    {r.name[0]}
                  </div>
                  <span className="font-display font-semibold text-sm text-slate-900">{r.name}</span>
                  <span className="ml-auto text-xs text-slate-400">Google Review</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── EMERGENCY CTA ── */}
      <section className="bg-red-700 py-16 px-4 text-white text-center">
        <div className="max-w-3xl mx-auto">
          <div className="text-5xl mb-4">🚨</div>
          <h2 className="font-display font-extrabold text-3xl md:text-4xl mb-3">Medical Emergency?</h2>
          <p className="font-hindi text-xl text-red-100 mb-2">आपात स्थिति में तुरंत कॉल करें</p>
          <p className="text-red-100 mb-8">Our 24x7 ambulance and emergency team is always ready to help</p>
          <a href="tel:+917905711195"
            className="inline-block bg-white font-display font-extrabold text-2xl md:text-3xl px-10 py-5 rounded-2xl shadow-2xl hover:scale-105 transition-transform"
            style={{color:'#C0392B'}}>
            📞 +91 79057 11195
          </a>
          <p className="mt-4 text-red-200 text-sm">Available 24 Hours • 7 Days • All Holidays</p>
        </div>
      </section>

      {/* ── MAP ── */}
      <section className="py-20 px-4 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="section-title">Find Us</h2>
            <p className="section-sub">Chunar Road, near Hemen Jewellers, Awaleshpur, Varanasi</p>
          </div>
          <div className="rounded-2xl overflow-hidden shadow-xl border border-slate-200">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d903.0!2d82.9605177!3d25.2560248!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x398e330075ae8a75%3A0xf7b76d0b70422428!2sHope%20Hospital!5e0!3m2!1sen!2sin!4v1718000000000!5m2!1sen!2sin"
              width="100%" height="400" style={{ border: 0 }}
              allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
          <div className="mt-6 flex flex-col sm:flex-row gap-4 justify-center">
            <a href="https://maps.google.com/?q=Hope+Hospital+Varanasi" target="_blank" rel="noopener noreferrer" className="btn-primary text-center">
              📍 Open in Google Maps
            </a>
            <a href="https://wa.me/917905711195?text=Hello%2C%20I%20need%20directions%20to%20Hope%20Hospital%2C%20Varanasi" target="_blank" rel="noopener noreferrer" className="btn-outline text-center">
              💬 Ask on WhatsApp
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}
