import Link from 'next/link'

export const metadata = {
  title: 'About Hope Hospital | Varanasi | BHU Affiliated',
  description: 'Learn about Hope Hospital Varanasi — BHU affiliated multi-specialty hospital on Chunar Road, serving patients with expert surgical care, ICU, NICU, and 24x7 emergency services.',
}

export default function AboutPage() {
  return (
    <div>
      {/* Header */}
      <section className="bg-gradient-to-r from-navy to-blue-800 text-white py-16 px-4 text-center">
        <p className="font-hindi text-blue-200 text-xl mb-2">हमारे बारे में</p>
        <h1 className="font-display font-extrabold text-4xl md:text-5xl mb-4">About Hope Hospital</h1>
        <p className="text-blue-100 max-w-2xl mx-auto">A trusted name in healthcare — serving patients of Varanasi and surrounding areas with compassion and expertise.</p>
      </section>

      {/* Story */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-red-700 font-display font-semibold text-sm uppercase tracking-widest mb-3">Our Story</p>
              <h2 className="font-display font-bold text-3xl text-slate-900 mb-6">Quality Healthcare, Close to Home</h2>
              <p className="text-slate-500 leading-relaxed mb-4">
                Hope Hospital was founded with a single mission: to bring BHU-level medical expertise directly to the people of Varanasi's southern districts. Located on Chunar Road in Awaleshpur, we serve thousands of patients each year with world-class surgical care and compassionate treatment.
              </p>
              <p className="text-slate-500 leading-relaxed mb-4">
                Our team of doctors — all trained at the prestigious Institute of Medical Sciences (IMS), Banaras Hindu University — brings the highest standards of medical practice to a community that deserves nothing less.
              </p>
              <p className="text-slate-500 leading-relaxed">
                With 10+ specialties, 24x7 emergency services, fully equipped ICU and NICU, we are ready for every medical need at any hour of the day.
              </p>
            </div>
            <div className="space-y-4">
              {[
                { icon: '🎯', title: 'Our Mission', text: 'To provide expert, affordable, and compassionate healthcare to every patient who walks through our doors.' },
                { icon: '👁️', title: 'Our Vision', text: 'To be the most trusted multi-specialty hospital in Varanasi — known for clinical excellence and patient-first care.' },
                { icon: '💎', title: 'Our Values', text: 'Compassion, Integrity, Excellence, Accessibility — the four pillars of everything we do.' },
              ].map(item => (
                <div key={item.title} className="bg-light rounded-2xl p-5 flex gap-4">
                  <div className="text-3xl">{item.icon}</div>
                  <div>
                    <h3 className="font-display font-bold text-navy text-base">{item.title}</h3>
                    <p className="text-slate-500 text-sm mt-1 leading-relaxed">{item.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose */}
      <section className="py-20 px-4 bg-slate-50">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="section-title mb-3">Why Choose Us</h2>
          <p className="section-sub mb-12">Trusted by thousands of patients across Varanasi</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { n: '4.9★', l: 'Google Rating' },
              { n: '193+', l: 'Patient Reviews' },
              { n: '10+', l: 'Specialties' },
              { n: '24x7', l: 'Emergency' },
            ].map(item => (
              <div key={item.n} className="card p-6 text-center">
                <div className="font-display font-extrabold text-3xl text-navy">{item.n}</div>
                <div className="text-slate-500 text-sm mt-2">{item.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* BHU Affiliation */}
      <section className="py-16 px-4 bg-navy text-white text-center">
        <div className="max-w-3xl mx-auto">
          <div className="text-5xl mb-4">🎓</div>
          <h2 className="font-display font-bold text-3xl mb-4">BHU Affiliated — A Mark of Excellence</h2>
          <p className="text-blue-100 leading-relaxed">
            All Hope Hospital doctors hold degrees from the Institute of Medical Sciences (IMS), Banaras Hindu University — one of India's highest-ranked medical universities. This means every patient receives care backed by world-class medical training and evidence-based practices.
          </p>
          <Link href="/doctors" className="mt-8 inline-block bg-white text-navy font-display font-bold px-8 py-4 rounded-xl hover:bg-blue-50 transition-colors">
            Meet Our Doctors →
          </Link>
        </div>
      </section>
    </div>
  )
}
