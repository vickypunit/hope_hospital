'use client'
import { useState } from 'react'
import { useForm } from 'react-hook-form'

const DOCTORS = ['Dr. Anil Kumar Tripathi (General & Laparoscopy / Ano Rectal)', 'Dr. Anjita Kurei (Gynecology & Obstetrics)', 'Any Available Doctor']
const DEPTS   = ['General Surgery', 'Laparoscopic Surgery', 'Gynecology & Obstetrics', 'Nephrology & Urology', 'Neurology', 'Cosmetic & Plastic Surgery', 'Fracture & Trauma', 'Cancer Surgery', 'ICU', 'NICU / Pediatrics', 'Other']

export default function AppointmentPage() {
  const [submitted, setSubmitted] = useState(false)
  const { register, handleSubmit, formState: { errors }, watch } = useForm()

  const onSubmit = (data) => {
    const msg = `🏥 *New Appointment Request — Hope Hospital*\n\n` +
      `👤 *Patient:* ${data.name}\n` +
      `📞 *Phone:* ${data.phone}\n` +
      `🎂 *Age:* ${data.age} | *Gender:* ${data.gender}\n` +
      `👨‍⚕️ *Doctor:* ${data.doctor}\n` +
      `🏥 *Department:* ${data.department}\n` +
      `📅 *Date:* ${data.date} | *Slot:* ${data.slot}\n` +
      `📧 *Email:* ${data.email || 'Not provided'}\n` +
      `📝 *Problem:* ${data.problem || 'Not specified'}`

    window.open(`https://wa.me/917905711195?text=${encodeURIComponent(msg)}`, '_blank')
    setSubmitted(true)
  }

  if (submitted) return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
      <div className="card max-w-md w-full p-10 text-center">
        <div className="text-6xl mb-4">✅</div>
        <h2 className="font-display font-bold text-2xl text-slate-900 mb-2">Appointment Request Sent!</h2>
        <p className="font-hindi text-slate-500 text-lg mb-4">आपकी अपॉइंटमेंट रिक्वेस्ट भेज दी गई है।</p>
        <p className="text-slate-500 text-sm mb-8">Our team will call you within 30 minutes to confirm your appointment.</p>
        <a href="tel:+917905711195" className="btn-red block mb-3">📞 Call Now for Faster Booking</a>
        <a href="/" className="btn-outline block">← Back to Home</a>
      </div>
    </div>
  )

  return (
    <div>
      {/* Header */}
      <section className="bg-gradient-to-r from-navy to-blue-800 text-white py-14 px-4 text-center">
        <p className="font-hindi text-blue-200 text-xl mb-2">अपॉइंटमेंट बुक करें</p>
        <h1 className="font-display font-extrabold text-4xl md:text-5xl mb-3">Book an Appointment</h1>
        <p className="text-blue-100 max-w-xl mx-auto">Fill the form below. Your request will be sent directly to WhatsApp and our team will confirm shortly.</p>
      </section>

      <section className="py-16 px-4 bg-slate-50">
        <div className="max-w-2xl mx-auto">
          {/* Quick call */}
          <div className="bg-red-700 text-white rounded-2xl p-5 mb-8 text-center">
            <p className="font-display font-semibold mb-2">For immediate appointments or emergencies:</p>
            <a href="tel:+917905711195" className="font-display font-extrabold text-2xl underline">📞 +91 79057 11195</a>
            <p className="text-red-200 text-sm mt-1">Available 24x7</p>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="card p-8 space-y-6">
            <h2 className="font-display font-bold text-xl text-slate-900 border-b pb-4">Patient Information</h2>

            {/* Name */}
            <div>
              <label className="block text-sm font-display font-semibold text-slate-900 mb-1">Full Name *</label>
              <input {...register('name', { required: 'Name is required', minLength: { value: 2, message: 'Min 2 characters' } })}
                className="w-full border border-gray-200 rounded-lg px-4 py-3 text-slate-900 focus:outline-none focus:border-navy focus:ring-2 focus:ring-navy/20 transition"
                placeholder="Enter patient name" />
              {errors.name && <p className="text-red-700 text-xs mt-1">{errors.name.message}</p>}
            </div>

            {/* Phone */}
            <div>
              <label className="block text-sm font-display font-semibold text-slate-900 mb-1">Mobile Number *</label>
              <input {...register('phone', { required: 'Phone is required', pattern: { value: /^[6-9]\d{9}$/, message: 'Enter valid 10-digit mobile number' } })}
                type="tel" placeholder="10-digit mobile number"
                className="w-full border border-gray-200 rounded-lg px-4 py-3 text-slate-900 focus:outline-none focus:border-navy focus:ring-2 focus:ring-navy/20 transition" />
              {errors.phone && <p className="text-red-700 text-xs mt-1">{errors.phone.message}</p>}
            </div>

            {/* Age + Gender */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-display font-semibold text-slate-900 mb-1">Age *</label>
                <input {...register('age', { required: 'Required', min: { value: 1, message: 'Invalid age' }, max: { value: 120, message: 'Invalid age' } })}
                  type="number" placeholder="Age"
                  className="w-full border border-gray-200 rounded-lg px-4 py-3 text-slate-900 focus:outline-none focus:border-navy focus:ring-2 focus:ring-navy/20 transition" />
                {errors.age && <p className="text-red-700 text-xs mt-1">{errors.age.message}</p>}
              </div>
              <div>
                <label className="block text-sm font-display font-semibold text-slate-900 mb-1">Gender *</label>
                <select {...register('gender', { required: 'Required' })}
                  className="w-full border border-gray-200 rounded-lg px-4 py-3 text-slate-900 focus:outline-none focus:border-navy focus:ring-2 focus:ring-navy/20 transition">
                  <option value="">Select</option>
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
                {errors.gender && <p className="text-red-700 text-xs mt-1">{errors.gender.message}</p>}
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-display font-semibold text-slate-900 mb-1">Email (Optional)</label>
              <input {...register('email')} type="email" placeholder="email@example.com"
                className="w-full border border-gray-200 rounded-lg px-4 py-3 text-slate-900 focus:outline-none focus:border-navy focus:ring-2 focus:ring-navy/20 transition" />
            </div>

            <h2 className="font-display font-bold text-xl text-slate-900 border-b pb-4 pt-2">Appointment Details</h2>

            {/* Doctor */}
            <div>
              <label className="block text-sm font-display font-semibold text-slate-900 mb-1">Select Doctor *</label>
              <select {...register('doctor', { required: 'Please select a doctor' })}
                className="w-full border border-gray-200 rounded-lg px-4 py-3 text-slate-900 focus:outline-none focus:border-navy focus:ring-2 focus:ring-navy/20 transition">
                <option value="">Choose Doctor</option>
                {DOCTORS.map(d => <option key={d}>{d}</option>)}
              </select>
              {errors.doctor && <p className="text-red-700 text-xs mt-1">{errors.doctor.message}</p>}
            </div>

            {/* Department */}
            <div>
              <label className="block text-sm font-display font-semibold text-slate-900 mb-1">Department *</label>
              <select {...register('department', { required: 'Please select department' })}
                className="w-full border border-gray-200 rounded-lg px-4 py-3 text-slate-900 focus:outline-none focus:border-navy focus:ring-2 focus:ring-navy/20 transition">
                <option value="">Choose Department</option>
                {DEPTS.map(d => <option key={d}>{d}</option>)}
              </select>
              {errors.department && <p className="text-red-700 text-xs mt-1">{errors.department.message}</p>}
            </div>

            {/* Date */}
            <div>
              <label className="block text-sm font-display font-semibold text-slate-900 mb-1">Preferred Date *</label>
              <input {...register('date', { required: 'Please select a date' })} type="date"
                min={new Date().toISOString().split('T')[0]}
                className="w-full border border-gray-200 rounded-lg px-4 py-3 text-slate-900 focus:outline-none focus:border-navy focus:ring-2 focus:ring-navy/20 transition" />
              {errors.date && <p className="text-red-700 text-xs mt-1">{errors.date.message}</p>}
            </div>

            {/* Time Slot */}
            <div>
              <label className="block text-sm font-display font-semibold text-slate-900 mb-2">Preferred Time Slot *</label>
              <div className="grid grid-cols-2 gap-3">
                {['Morning (9:00 AM – 1:00 PM)', 'Evening (5:00 PM – 8:00 PM)'].map(slot => (
                  <label key={slot} className="flex items-center gap-3 border border-gray-200 rounded-lg px-4 py-3 cursor-pointer hover:border-navy transition-colors has-[:checked]:border-navy has-[:checked]:bg-light">
                    <input {...register('slot', { required: 'Please select a time slot' })} type="radio" value={slot} className="accent-navy" />
                    <span className="text-sm text-slate-900">{slot}</span>
                  </label>
                ))}
              </div>
              {errors.slot && <p className="text-red-700 text-xs mt-1">{errors.slot.message}</p>}
            </div>

            {/* Problem */}
            <div>
              <label className="block text-sm font-display font-semibold text-slate-900 mb-1">Problem / Symptoms (Optional)</label>
              <textarea {...register('problem')} rows={4} placeholder="Briefly describe your symptoms or reason for visit..."
                maxLength={500}
                className="w-full border border-gray-200 rounded-lg px-4 py-3 text-slate-900 focus:outline-none focus:border-navy focus:ring-2 focus:ring-navy/20 transition resize-none" />
              <p className="text-xs text-slate-500 mt-1">{watch('problem')?.length || 0}/500 characters</p>
            </div>

            <button type="submit"
              className="w-full bg-navy text-white font-display font-bold text-lg py-4 rounded-xl hover:bg-blue-900 transition-colors flex items-center justify-center gap-2">
              💬 Send via WhatsApp
            </button>
            <p className="text-xs text-slate-500 text-center">Your details will be sent to our WhatsApp. We will confirm your appointment within 30 minutes.</p>
          </form>
        </div>
      </section>
    </div>
  )
}
