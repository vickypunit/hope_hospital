import Link from 'next/link'

export const metadata = {
  title: '24x7 Emergency & Ambulance | Hope Hospital Varanasi | +91 79057 11195',
  description: '24x7 emergency care at Hope Hospital Varanasi. Ambulance service available immediately. Call +91 79057 11195 for emergency medical assistance.',
}

export default function EmergencyPage() {
  return (
    <div>
      {/* BIG Emergency Hero */}
      <section className="bg-red-700 text-white py-20 px-4 text-center">
        <div className="text-7xl mb-6 animate-pulse">🚨</div>
        <h1 className="font-display font-extrabold text-4xl md:text-6xl mb-4">Medical Emergency?</h1>
        <p className="font-hindi text-2xl text-red-100 mb-8">आपात स्थिति में तुरंत कॉल करें</p>
        <a href="tel:+917905711195"
          className="inline-block bg-white text-red-700 font-display font-extrabold text-3xl md:text-4xl px-12 py-6 rounded-2xl shadow-2xl hover:scale-105 transition-transform">
          📞 +91 79057 11195
        </a>
        <p className="mt-6 text-red-100 text-lg font-semibold">Available 24 Hours • 7 Days • All Holidays</p>
        <p className="font-hindi text-red-200 mt-2">24 घंटे • सातों दिन • सभी त्योहारों पर</p>
      </section>

      {/* Emergency Services */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-5xl mx-auto">
          <h2 className="section-title text-center mb-10">Emergency Services Available</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: '🚑', title: '24x7 Ambulance', desc: 'Rapid response ambulance service available immediately on call. Equipped with emergency medical equipment.' },
              { icon: '🏥', title: 'ICU — Intensive Care Unit', desc: 'Fully equipped ICU with advanced life support for critically ill patients. Round-the-clock monitoring.' },
              { icon: '👶', title: 'NICU — Neonatal ICU', desc: 'Specialized neonatal care unit for newborns requiring critical attention and monitoring.' },
              { icon: '🦴', title: 'Trauma & Fracture', desc: 'Emergency trauma surgery and fracture management. Available 24x7 for accident cases.' },
              { icon: '🔬', title: 'Emergency Surgery', desc: 'Experienced surgical team ready for emergency operations at any hour.' },
              { icon: '💊', title: 'Emergency Medicine', desc: 'Immediate medical stabilization and treatment for all types of medical emergencies.' },
            ].map(item => (
              <div key={item.title} className="card p-6 border-l-4 border-l-red-600">
                <div className="text-4xl mb-3">{item.icon}</div>
                <h3 className="font-display font-bold text-slate-900 text-lg mb-2">{item.title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* What to do */}
      <section className="py-16 px-4 bg-slate-50">
        <div className="max-w-3xl mx-auto">
          <h2 className="section-title text-center mb-10">What To Do In An Emergency</h2>
          <div className="space-y-4">
            {[
              { step: '1', title: 'Call Immediately', desc: 'Call +91 79057 11195 right away. Our emergency team picks up 24x7.', color: 'bg-red-700' },
              { step: '2', title: 'Share Your Location', desc: 'Tell us your exact location or nearby landmark. We will dispatch ambulance immediately.', color: 'bg-red-700' },
              { step: '3', title: 'Stay Calm', desc: 'Keep the patient calm and still. Do not move if there is a suspected spine or head injury.', color: 'bg-navy' },
              { step: '4', title: 'We Reach You', desc: 'Our ambulance will reach you as quickly as possible. Emergency team will be ready on arrival.', color: 'bg-emerald-600' },
            ].map(item => (
              <div key={item.step} className="card p-6 flex gap-5 items-start">
                <div className={`${item.color} text-white font-display font-extrabold text-xl w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0`}>
                  {item.step}
                </div>
                <div>
                  <h3 className="font-display font-bold text-slate-900 text-lg">{item.title}</h3>
                  <p className="text-slate-500 text-sm mt-1 leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Address */}
      <section className="py-12 px-4 bg-dark text-white text-center">
        <div className="max-w-2xl mx-auto">
          <h2 className="font-display font-bold text-2xl mb-4">Hospital Location</h2>
          <p className="text-slate-500-300 mb-2">📍 Chunar Road, near Hemen Jewellers, Awaleshpur, Varanasi, UP 221106</p>
          <a href="https://maps.google.com/?q=Hope+Hospital+Varanasi" target="_blank" rel="noopener noreferrer"
            className="inline-block mt-4 bg-white text-slate-900 font-display font-semibold px-6 py-3 rounded-xl hover:bg-slate-100 transition-colors">
            📍 Open Directions in Google Maps
          </a>
          <div className="mt-6">
            <a href="tel:+917905711195"
              className="inline-block bg-red-700 font-display font-bold text-xl px-10 py-4 rounded-xl hover:bg-red-800 transition-colors">
              🚨 Call Emergency Now
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}
