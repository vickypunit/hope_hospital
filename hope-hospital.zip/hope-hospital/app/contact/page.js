import Link from 'next/link'

export const metadata = {
  title: 'Contact Hope Hospital | Chunar Road Varanasi | +91 79057 11195',
  description: 'Contact Hope Hospital Varanasi. Address: Chunar Rd, Awaleshpur, Varanasi UP 221106. Phone: +91 79057 11195. Open 24x7.',
}

export default function ContactPage() {
  return (
    <div>
      {/* Header */}
      <section className="bg-gradient-to-r from-navy to-blue-800 text-white py-16 px-4 text-center">
        <p className="font-hindi text-blue-200 text-xl mb-2">संपर्क करें</p>
        <h1 className="font-display font-extrabold text-4xl md:text-5xl mb-4">Contact Us</h1>
        <p className="text-blue-100">We are here 24x7 — reach us anytime.</p>
      </section>

      <section className="py-20 px-4 bg-slate-50">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Info */}
          <div className="space-y-6">
            <div className="card p-6">
              <h2 className="font-display font-bold text-xl text-navy mb-6">Get In Touch</h2>
              <div className="space-y-5">
                <div className="flex gap-4 items-start">
                  <div className="text-2xl">📍</div>
                  <div>
                    <p className="font-display font-semibold text-slate-900">Address</p>
                    <p className="text-slate-500 text-sm mt-1">Chunar Road, near Hemen Jewellers, Awaleshpur, Varanasi, Uttar Pradesh 221106</p>
                    <a href="https://maps.google.com/?q=Hope+Hospital+Varanasi" target="_blank" rel="noopener noreferrer"
                      className="text-navy text-sm font-semibold hover:underline mt-1 inline-block">Open in Maps →</a>
                  </div>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="text-2xl">📞</div>
                  <div>
                    <p className="font-display font-semibold text-slate-900">Phone</p>
                    <a href="tel:+917905711195" className="text-navy font-bold text-lg hover:underline">+91 79057 11195</a>
                    <p className="text-slate-500 text-xs mt-1">Click to call on mobile</p>
                  </div>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="text-2xl">🕐</div>
                  <div>
                    <p className="font-display font-semibold text-slate-900">Working Hours</p>
                    <p className="text-success font-bold text-lg">🟢 Open 24 Hours, 7 Days a Week</p>
                    <p className="text-slate-500 text-xs mt-1">Including all public holidays and festivals</p>
                  </div>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="text-2xl">💬</div>
                  <div>
                    <p className="font-display font-semibold text-slate-900">WhatsApp</p>
                    <a href="https://wa.me/917905711195" target="_blank" rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 bg-green-600 text-white font-semibold px-4 py-2 rounded-lg text-sm hover:bg-green-700 transition-colors mt-1">
                      💬 Chat on WhatsApp
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* OPD Timings table */}
            <div className="card p-6">
              <h3 className="font-display font-bold text-lg text-navy mb-4">OPD Schedule</h3>
              <div className="space-y-2 text-sm">
                {[
                  ['General OPD', 'Mon–Sat', '9:00 AM – 2:00 PM'],
                  ['Evening OPD', 'Mon–Sat', '5:00 PM – 8:00 PM'],
                  ['Emergency', 'All Days', '24x7 (Always Open)'],
                  ['ICU / NICU', 'All Days', '24x7 (Always Open)'],
                ].map(([dept, days, time]) => (
                  <div key={dept} className="flex justify-between items-center py-2 border-b border-gray-100 last:border-0">
                    <span className="font-semibold text-slate-900">{dept}</span>
                    <span className="text-slate-500">{days}</span>
                    <span className="text-navy font-medium">{time}</span>
                  </div>
                ))}
              </div>
            </div>

            <Link href="/appointment" className="btn-primary block text-center text-lg py-4">
              📅 Book Appointment Online
            </Link>
          </div>

          {/* Map */}
          <div className="space-y-6">
            <div className="rounded-2xl overflow-hidden shadow-xl border border-gray-200">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d903.0!2d82.9605177!3d25.2560248!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x398e330075ae8a75%3A0xf7b76d0b70422428!2sHope%20Hospital!5e0!3m2!1sen!2sin!4v1718000000000!5m2!1sen!2sin"
                width="100%"
                height="450"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
            <a href="https://maps.google.com/?q=Hope+Hospital+Chunar+Road+Varanasi" target="_blank" rel="noopener noreferrer"
              className="btn-outline block text-center">
              📍 Get Directions in Google Maps
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}
