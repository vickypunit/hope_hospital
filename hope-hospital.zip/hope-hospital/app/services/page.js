import Link from 'next/link'
import { services } from '../../data/services'

export const metadata = {
  title: 'Our Services | Hope Hospital Varanasi',
  description: '10+ medical specialties at Hope Hospital Varanasi — General Surgery, Laparoscopic, ICU, NICU, Gynecology, Neurology, Cancer Surgery and more. BHU affiliated doctors.',
}

export default function ServicesPage() {
  return (
    <div>
      {/* Header */}
      <section className="bg-gradient-to-r from-navy to-blue-800 text-white py-16 px-4 text-center">
        <p className="font-hindi text-blue-200 text-xl mb-2">हमारी सेवाएं</p>
        <h1 className="font-display font-extrabold text-4xl md:text-5xl mb-4">Our Medical Services</h1>
        <p className="text-blue-100 max-w-2xl mx-auto text-lg">
          10 specialties under one roof — expert, affordable, and compassionate care for every patient.
        </p>
      </section>

      {/* Services Grid */}
      <section className="py-20 px-4 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((s, i) => (
              <div key={s.id} className="card p-8 group border-2 border-transparent hover:border-navy transition-all duration-300">
                <div className="flex items-start justify-between mb-4">
                  <div className="text-5xl">{s.icon}</div>
                  <span className="text-xs text-slate-500 bg-slate-100 px-2 py-1 rounded-full font-mono">#{String(i+1).padStart(2,'0')}</span>
                </div>
                <h2 className="font-display font-bold text-slate-900 text-xl mb-1 group-hover:text-navy transition-colors">{s.name}</h2>
                <p className="font-hindi text-slate-500 text-sm mb-4">{s.nameHindi}</p>
                <p className="text-slate-500 text-sm leading-relaxed mb-6">{s.desc}</p>
                <Link href="/appointment"
                  className="w-full btn-primary text-sm py-2.5 block text-center">
                  Consult Now →
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-4 bg-navy text-white text-center">
        <h2 className="font-display font-bold text-3xl mb-3">Not sure which department you need?</h2>
        <p className="text-blue-200 mb-8">Call us and our team will guide you to the right specialist.</p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a href="tel:+917905711195" className="bg-white text-navy font-display font-bold px-8 py-4 rounded-xl hover:bg-blue-50 transition-colors">
            📞 Call +91 79057 11195
          </a>
          <Link href="/appointment" className="bg-red-700 font-display font-bold px-8 py-4 rounded-xl hover:bg-red-800 transition-colors">
            📅 Book Appointment
          </Link>
        </div>
      </section>
    </div>
  )
}
