import './globals.css'
import Navbar from '../components/layout/Navbar'
import Footer from '../components/layout/Footer'
import EmergencyStrip from '../components/layout/EmergencyStrip'

export const metadata = {
  title: 'Hope Hospital | 24x7 Multi-Specialty Hospital | Varanasi',
  description: 'Hope Hospital Varanasi — BHU-affiliated doctors, 10+ specialties, 24x7 emergency & ambulance service. Chunar Road, Awaleshpur. Call +91 79057 11195',
  keywords: 'Hope Hospital Varanasi, hospital near Chunar Road, BHU doctors Varanasi, 24x7 hospital Varanasi, surgery Varanasi',
}

export default function RootLayout({ children }) {
  return (
    <html lang="hi">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800&family=Inter:wght@400;500;600&family=Noto+Sans+Devanagari:wght@400;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="font-sans bg-white text-slate-900">
        <EmergencyStrip />
        <Navbar />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  )
}
