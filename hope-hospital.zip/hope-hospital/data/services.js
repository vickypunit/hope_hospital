export const services = [
  { id: 'general-surgery',      icon: '🔬', name: 'General Surgery & Medicine',        nameHindi: 'जनरल सर्जरी एवं मेडिसिन',              desc: 'Expert surgical care for all general conditions with modern techniques.' },
  { id: 'laparoscopic-surgery', icon: '🎯', name: 'Laparoscopic Surgery',              nameHindi: 'लेंग्रास्कोपी (दूरबीन विधि) सर्जरी',    desc: 'Minimally invasive surgery with faster recovery and smaller incisions.' },
  { id: 'gynecology',           icon: '👩‍⚕️', name: 'Gynecology & Obstetrics',          nameHindi: 'स्त्री एवं प्रसूति रोग विभाग',          desc: "Comprehensive women's health care from pregnancy to complex conditions." },
  { id: 'nephrology-urology',   icon: '🫁', name: 'Nephrology & Urology Surgery',      nameHindi: 'नेफ्रोलॉजी एवं यूरो सर्जरी',            desc: 'Advanced kidney and urological treatments by BHU trained specialists.' },
  { id: 'neurology',            icon: '🧠', name: 'Neurology & Neuro Surgery',         nameHindi: 'न्यूरोलॉजी एवं न्यूरो सर्जरी',          desc: 'Diagnosis and treatment of brain, spine and nervous system disorders.' },
  { id: 'cosmetic-surgery',     icon: '✨', name: 'Cosmetic & Plastic Surgery',        nameHindi: 'कास्मेटिक एवं प्लास्टिक सर्जरी',        desc: 'Reconstructive and aesthetic procedures by experienced plastic surgeons.' },
  { id: 'fracture-trauma',      icon: '🦴', name: 'Fracture & Trauma Surgery',         nameHindi: 'फेक्चर एवं ट्रामा सर्जरी',              desc: 'Emergency trauma care and fracture management available 24x7.' },
  { id: 'cancer-surgery',       icon: '🎗️', name: 'Cancer Surgery',                   nameHindi: 'कैंसर सर्जरी',                          desc: 'Surgical oncology with precision and compassionate post-op care.' },
  { id: 'icu',                  icon: '🏥', name: 'ICU — Intensive Care Unit',         nameHindi: 'गहन चिकित्सा कक्ष (ICU)',               desc: 'Round-the-clock critical care with advanced life support systems.' },
  { id: 'nicu',                 icon: '👶', name: 'NICU — Neonatal ICU',               nameHindi: 'बाल रोग विभाग एवं NICU',                desc: 'Specialized neonatal intensive care for newborns needing critical support.' },
]
