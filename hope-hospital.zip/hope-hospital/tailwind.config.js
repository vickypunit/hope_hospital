/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        navy:      '#1B4F8A',
        primary:   '#1B4F8A',
        danger:    '#C0392B',
        success:   '#1E8449',
        muted:     '#5D6D7E',
        light:     '#EBF5FB',
        dark:      '#1A1A2E',
      },
      fontFamily: {
        sans:    ['Inter', 'sans-serif'],
        display: ['Poppins', 'sans-serif'],
        hindi:   ['Noto Sans Devanagari', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
