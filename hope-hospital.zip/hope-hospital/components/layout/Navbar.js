'use client'
import { useState } from 'react'
import Link from 'next/link'

const links = [
  { href: '/',            label: 'Home' },
  { href: '/services',   label: 'Services' },
  { href: '/doctors',    label: 'Doctors' },
  { href: '/about',      label: 'About' },
  { href: '/contact',    label: 'Contact' },
  { href: '/emergency',  label: '🚨 Emergency' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 flex items-center justify-between h-16">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2">
          <span className="text-2xl">🏥</span>
          <div>
            <div className="font-display font-bold text-navy text-lg leading-tight">Hope Hospital</div>
            <div className="font-hindi text-xs text-slate-500 leading-tight">होप हॉस्पिटल • Varanasi</div>
          </div>
        </Link>

        {/* Desktop links */}
        <div className="hidden md:flex items-center gap-6">
          {links.map(l => (
            <Link key={l.href} href={l.href}
              className={`font-display text-sm font-medium transition-colors ${
                l.href === '/emergency'
                  ? 'text-red-700 hover:text-red-700-800 font-semibold'
                  : 'text-slate-900 hover:text-navy'
              }`}>
              {l.label}
            </Link>
          ))}
          <Link href="/appointment" className="btn-primary text-sm py-2 px-5">
            Book Appointment
          </Link>
        </div>

        {/* Mobile hamburger */}
        <button className="md:hidden p-2 text-slate-900" onClick={() => setOpen(!open)}>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            {open
              ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/>
              : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16"/>
            }
          </svg>
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden bg-white border-t border-gray-100 px-4 py-4 flex flex-col gap-3">
          {links.map(l => (
            <Link key={l.href} href={l.href} onClick={() => setOpen(false)}
              className={`font-display text-sm font-medium py-2 border-b border-gray-50 ${
                l.href === '/emergency' ? 'text-red-700 font-semibold' : 'text-slate-900'
              }`}>
              {l.label}
            </Link>
          ))}
          <Link href="/appointment" onClick={() => setOpen(false)} className="btn-primary text-sm text-center mt-2">
            Book Appointment
          </Link>
        </div>
      )}
    </nav>
  )
}
