'use client'
export default function EmergencyStrip() {
  return (
    <div className="bg-red-700 text-white text-sm py-2 px-4 text-center font-display font-semibold">
      <span className="mr-2">🚨 24x7 Emergency &amp; Ambulance Service</span>
      <a href="tel:+917905711195" className="underline underline-offset-2 font-bold tracking-wide hover:text-yellow-200 transition-colors">
        📞 +91 79057 11195
      </a>
      <span className="ml-2 hidden sm:inline">— Click to Call Now</span>
    </div>
  )
}
