import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="bg-dark text-white pt-12 pb-6">
      <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Brand */}
        <div className="md:col-span-1">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-2xl">🏥</span>
            <div>
              <div className="font-display font-bold text-white text-lg">Hope Hospital</div>
              <div className="font-hindi text-xs text-slate-500-400">होप हॉस्पिटल</div>
            </div>
          </div>
          <p className="text-slate-500-400 text-sm leading-relaxed">
            BHU-affiliated multi-specialty hospital providing 24x7 quality healthcare in Varanasi.
          </p>
          <div className="mt-4 flex gap-3">
            <span className="bg-emerald-600 text-white text-xs px-2 py-1 rounded font-semibold">⭐ 4.9/5</span>
            <span className="bg-navy text-white text-xs px-2 py-1 rounded font-semibold">193 Reviews</span>
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="font-display font-semibold text-white mb-4">Quick Links</h4>
          <ul className="space-y-2 text-sm text-slate-500-400">
            {['/', '/services', '/doctors', '/appointment', '/about', '/contact', '/emergency'].map((href, i) => (
              <li key={href}>
                <Link href={href} className="hover:text-white transition-colors">
                  {['Home', 'Services', 'Doctors', 'Book Appointment', 'About Us', 'Contact', '🚨 Emergency'][i]}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Services */}
        <div>
          <h4 className="font-display font-semibold text-white mb-4">Our Services</h4>
          <ul className="space-y-2 text-sm text-slate-500-400">
            {['General Surgery', 'Laparoscopic Surgery', 'Gynecology', 'Neurology', 'Cancer Surgery', 'ICU & NICU', 'Fracture & Trauma'].map(s => (
              <li key={s}><Link href="/services" className="hover:text-white transition-colors">{s}</Link></li>
            ))}
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h4 className="font-display font-semibold text-white mb-4">Contact Us</h4>
          <ul className="space-y-3 text-sm text-slate-500-400">
            <li className="flex gap-2">
              <span>📍</span>
              <span>Chunar Rd, near Hemen Jewellers, Awaleshpur, Varanasi, UP 221106</span>
            </li>
            <li>
              <a href="tel:+917905711195" className="flex gap-2 hover:text-white transition-colors">
                <span>📞</span><span className="font-semibold text-white">+91 79057 11195</span>
              </a>
            </li>
            <li className="flex gap-2">
              <span>🕐</span><span className="text-emerald-700 font-semibold">24x7 Open — All Days</span>
            </li>
            <li>
              <a href={`https://wa.me/917905711195`} target="_blank" rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-emerald-600 text-white px-3 py-2 rounded-lg text-xs font-semibold hover:bg-green-700 transition-colors mt-1">
                💬 WhatsApp Us
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 mt-10 pt-6 border-t border-gray-800 flex flex-col md:flex-row items-center justify-between gap-2 text-xs text-slate-500-500">
        <span>© {new Date().getFullYear()} Hope Hospital, Varanasi. All rights reserved.</span>
        <span>Designed for patient convenience • BHU Affiliated</span>
      </div>
    </footer>
  )
}
