'use client'
import { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import { services } from '../../data/services'

export default function ServicesSlider() {
  const [current, setCurrent] = useState(0)
  const [paused, setPaused] = useState(false)
  const timerRef = useRef(null)

  const total = services.length
  const visibleCount = 3 // cards visible at once on desktop

  const next = () => setCurrent(c => (c + 1) % total)
  const prev = () => setCurrent(c => (c - 1 + total) % total)
  const goTo = (i) => setCurrent(i)

  useEffect(() => {
    if (!paused) {
      timerRef.current = setInterval(() => {
        setCurrent(c => (c + 1) % total)
      }, 3000)
    }
    return () => clearInterval(timerRef.current)
  }, [paused, total])

  // Get 3 visible cards (wrapping)
  const visibleServices = [0, 1, 2].map(offset => services[(current + offset) % total])

  return (
    <section className="py-20 px-4 bg-slate-50">
      <div className="max-w-6xl mx-auto">
        {/* Heading */}
        <div className="text-center mb-12">
          <p className="font-semibold text-sm uppercase tracking-widest mb-2" style={{ color: '#C0392B', fontFamily: 'Poppins, sans-serif' }}>
            What We Offer
          </p>
          <h2 className="section-title">Our Medical Services</h2>
          <p className="section-sub">10 specialties under one roof — expert care for every need</p>
        </div>

        {/* Slider */}
        <div
          className="relative"
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
        >
          {/* Cards — desktop: 3 visible, mobile: 1 */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 transition-all duration-500">
            {visibleServices.map((s, i) => (
              <div key={`${s.id}-${i}`}
                className="card p-6 group border-2 border-transparent hover:border-blue-200 transition-all duration-300 animate-fadeIn">
                <div className="flex items-start justify-between mb-4">
                  <div className="text-5xl">{s.icon}</div>
                  <span className="text-xs text-slate-400 bg-slate-100 px-2 py-1 rounded-full font-mono">
                    {String(services.indexOf(s) + 1).padStart(2, '0')}/{String(total).padStart(2, '0')}
                  </span>
                </div>
                <h3 className="font-bold text-slate-900 text-lg mb-1 group-hover:text-navy transition-colors"
                  style={{ fontFamily: 'Poppins, sans-serif' }}>
                  {s.name}
                </h3>
                <p className="text-slate-400 text-xs mb-3" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>
                  {s.nameHindi}
                </p>
                <p className="text-slate-500 text-sm leading-relaxed mb-5">{s.desc}</p>
                <Link href="/appointment"
                  className="inline-flex items-center gap-1 text-sm font-semibold transition-colors"
                  style={{ color: '#1B4F8A', fontFamily: 'Poppins, sans-serif' }}>
                  Consult Now <span className="group-hover:translate-x-1 transition-transform inline-block">→</span>
                </Link>
              </div>
            ))}
          </div>

          {/* Prev / Next buttons */}
          <button onClick={prev}
            className="absolute -left-5 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full shadow-lg flex items-center justify-center text-white font-bold text-lg transition hover:scale-110 z-10 hidden sm:flex"
            style={{ backgroundColor: '#1B4F8A' }}>
            ‹
          </button>
          <button onClick={next}
            className="absolute -right-5 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full shadow-lg flex items-center justify-center text-white font-bold text-lg transition hover:scale-110 z-10 hidden sm:flex"
            style={{ backgroundColor: '#1B4F8A' }}>
            ›
          </button>
        </div>

        {/* Dots */}
        <div className="flex justify-center gap-2 mt-8">
          {services.map((_, i) => (
            <button key={i} onClick={() => goTo(i)}
              className={`rounded-full transition-all duration-300 ${i === current ? 'w-6 h-3' : 'w-3 h-3 opacity-40'}`}
              style={{ backgroundColor: '#1B4F8A' }} />
          ))}
        </div>

        {/* Progress bar */}
        <div className="mt-4 max-w-xs mx-auto h-1 bg-slate-200 rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-300"
            style={{ width: `${((current + 1) / total) * 100}%`, backgroundColor: '#1B4F8A' }}
          />
        </div>

        {/* View all */}
        <div className="text-center mt-8">
          <Link href="/services" className="btn-outline">
            View All Services →
          </Link>
        </div>
      </div>

      <style jsx>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn { animation: fadeIn 0.4s ease; }
      `}</style>
    </section>
  )
}
